package com.sp.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sp.model.JsonData;
import com.sp.service.JsonReaderService;

@RestController
public class JsonReaderController {

	@Autowired
	JsonReaderService jsonReaderService;

	@GetMapping
	public List<JsonData> getColor() {
		try {
			return jsonReaderService.getJson();
		} catch (IOException e) {
			System.out.println("Error occured while reading data.");
			return Collections.emptyList();
		}
		
	}
}
