package com.sp.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sp.model.JsonData;

@Service
public class JsonReaderService {

	@Autowired
	private ResourceLoader resourceLoader;

	public List<JsonData> getJson() throws IOException {
		List<JsonData> jsonObjList = new ArrayList<>();
		Resource resource = resourceLoader.getResource("classpath:JsonExample.json");
		InputStream inputStream = resource.getInputStream();
		byte[] fileData = FileCopyUtils.copyToByteArray(inputStream);
		String outputString = new String(fileData);
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			JsonData[] myColors = objectMapper.readValue(outputString, JsonData[].class);
			jsonObjList.addAll(Arrays.asList(myColors));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObjList.stream().filter(p -> p.getColor().equalsIgnoreCase("green")).collect(Collectors.toList());
	
	}
}
