package com.sp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
